package apps.sling_test.script;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

@Model(adaptables=Resource.class) 
public class MyModel { 

  @Inject
  private Resource resource; 

  @Inject
  private String titre; 


  private String value; 

  @PostConstruct 
  public void activate() { 

  } 

  public String getTitle() { 
    return "Mon très beau " + titre; 
  } 
}
